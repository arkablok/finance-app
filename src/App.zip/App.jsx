import { Routes, Route, Navigate, NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, ArrowLeftRight, PiggyBank, Target, Tags, LogOut
} from 'lucide-react';
import { useAuth } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Transactions from './pages/Transactions';
import Savings from './pages/Savings';
import Budgets from './pages/Budgets';
import Categories from './pages/Categories';

function AppLayout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate('/login', { replace: true });
  }

  const nav = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
    { to: '/transactions', label: 'Transaksi', icon: ArrowLeftRight },
    { to: '/savings', label: 'Tabungan', icon: PiggyBank },
    { to: '/budgets', label: 'Budget', icon: Target },
    { to: '/categories', label: 'Kategori', icon: Tags },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">💰 FinanceApp</div>
        <nav>
          {nav.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) => (isActive ? 'active' : '')}
              >
                <Icon size={18} /> {item.label}
              </NavLink>
            );
          })}
        </nav>
        <hr />
        <div className="px-2 small text-muted mb-2">
          {user?.nama}<br />
          <span className="text-truncate d-inline-block" style={{ maxWidth: '100%' }}>{user?.email}</span>
        </div>
        <button className="btn btn-sm btn-outline-secondary w-100 d-flex align-items-center justify-content-center gap-2" onClick={handleLogout}>
          <LogOut size={14} /> Keluar
        </button>
      </aside>
      <main className="main-content">{children}</main>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <AppLayout>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/transactions" element={<Transactions />} />
                <Route path="/savings" element={<Savings />} />
                <Route path="/budgets" element={<Budgets />} />
                <Route path="/categories" element={<Categories />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </AppLayout>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}